package application;

import java.io.IOException;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class PokerController {
	ObservableList<String> test = FXCollections.observableArrayList("2","3","4");
	//private ObservableList<String> numOfPpl;

	private Stage stage;
	private Scene scene;
	private Parent root;
	private String access;
	@FXML
	private Button myButton;
	@FXML
	private ChoiceBox<String> numOfPart;
	@FXML
	private void initialize() {
		numOfPart.setValue("Choose number of participants");
		numOfPart.setItems(test);	
	}
	
	public void switchToPoker(ActionEvent event) throws IOException {
	String choice = numOfPart.getValue();
	if("2".equals(choice) || "3".equals(choice || "4".equals(choice)) {
		Parent root = FXMLLoader.load(getClass().getResource("/PokerTable4.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
		
		Parent root = FXMLLoader.load(getClass().getResource("/PokerTable3.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();

		Parent root = FXMLLoader.load(getClass().getResource("/PokerTable2.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
}
